//
//  main.m
//  TRUNetworking
//
//  Created by xupengju on 12/18/2018.
//  Copyright (c) 2018 xupengju. All rights reserved.
//

@import UIKit;
#import "XPJAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([XPJAppDelegate class]));
    }
}
