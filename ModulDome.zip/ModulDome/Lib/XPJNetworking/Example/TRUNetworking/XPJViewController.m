//
//  XPJViewController.m
//  TRUNetworking
//
//  Created by xupengju on 12/18/2018.
//  Copyright (c) 2018 xupengju. All rights reserved.
//

#import "XPJViewController.h"

@interface XPJViewController ()

@end

@implementation XPJViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
