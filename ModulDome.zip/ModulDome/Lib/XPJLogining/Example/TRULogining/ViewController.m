//
//  ViewController.m
//  TRULogining
//
//  Created by xupengju on 2018/12/18.
//  Copyright © 2018年 guohongtao. All rights reserved.
//

#import "ViewController.h"
#import <XPJLogining/LoginViewController.h>

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // Do any additional setup after loading the view, typically from a nib.
}
- (IBAction)loginAction:(id)sender {
    LoginViewController *loginVc = [[LoginViewController alloc] init];
    [self.navigationController pushViewController:loginVc animated:YES];
}


@end
