//
//  LoginViewController.h
//  Pods-TRULogining
//
//  Created by xupengju on 2018/12/18.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface LoginViewController : UIViewController
@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong) NSString *password;
@end

NS_ASSUME_NONNULL_END
