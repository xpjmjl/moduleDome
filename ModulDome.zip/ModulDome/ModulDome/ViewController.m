//
//  ViewController.m
//  ModulDome
//
//  Created by xupengju on 2018/12/18.
//  Copyright © 2018年 guohongtao. All rights reserved.
//

#import "ViewController.h"
#import <JLRoutes/JLRoutes.h>

@interface Model : NSObject
@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong) NSString *password;
@end

@implementation Model



@end

@interface ViewController ()
@end 

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}
- (IBAction)gotoLoginAction:(id)sender {
    NSString *url = [NSString stringWithFormat:@"module://push/LoginViewController/2/1?name=user&password=123456"];
    Model *model = [[Model alloc] init];
    model.name = @"4444";
    model.password = @"555";
    void (^block)(NSString *) = ^(NSString *value) {
        NSLog(@"%@", value);
    };
    [JLRoutes routeURL:[NSURL URLWithString:url] withParameters:@{@"block":block, @"model":model}];
}
@end
