//
//  LCLaunchModule.h
//  Pods
//
//  Created by MengLingChao on 2018/9/26.
//

#import <Foundation/Foundation.h>
#import "LCLaunchModuleProtocol.h"

@interface LCLaunchModule : NSObject<LCLaunchModule>

@end
