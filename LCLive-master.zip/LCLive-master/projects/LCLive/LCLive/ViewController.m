//
//  ViewController.m
//  LCLive
//
//  Created by MengLingChao on 2018/7/6.
//  Copyright © 2018年 MengLingChao. All rights reserved.
//

#import "ViewController.h"
#import <objc/runtime.h>

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
//    NSString *hehe = @"LCHehe";
//    const char *name = hehe.UTF8String;
//    Class oneClass = objc_getClass(name);
//    Class meVCClass =  NSClassFromString(@"LCMeViewController");
//    Class meModuleClass =  NSClassFromString(@"LCMeModule");
//    Class heheClass =  NSClassFromString(@"LCHehe");
//    Class aClass =  NSClassFromString(@"LCUserModule");
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
