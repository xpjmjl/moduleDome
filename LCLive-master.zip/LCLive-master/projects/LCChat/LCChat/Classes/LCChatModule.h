//
//  LCChatModule.h
//  LCChat
//
//  Created by MengLingChao on 2018/7/8.
//  Copyright © 2018年 MengLingChao. All rights reserved.
//

#import <Foundation/Foundation.h>
//#import <LCMediator/LCChatModuleProtocol.h>
#import "LCChatModuleProtocol.h"

@interface LCChatModule : NSObject<LCChatModule>

@end
