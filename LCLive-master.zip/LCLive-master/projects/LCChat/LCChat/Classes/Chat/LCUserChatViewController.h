//
//  LCChatViewController.h
//  Pods
//
//  Created by MengLingChao on 2018/7/10.
//

#import <UIKit/UIKit.h>

/**单聊详情*/
@interface LCUserChatViewController : UIViewController

@property (nonatomic,copy)NSString *userId;

@end
