//
//  LCShareProtocol.h
//  Pods
//
//  Created by MengLingChao on 2018/8/13.
//

#import <Foundation/Foundation.h>

@protocol LCShareProtocol <NSObject>

+ (void)login;

@end
