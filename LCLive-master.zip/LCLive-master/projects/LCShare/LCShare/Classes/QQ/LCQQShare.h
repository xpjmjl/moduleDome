//
//  LCQQShare.h
//  Pods
//
//  Created by MengLingChao on 2018/8/13.
//

#import <Foundation/Foundation.h>
#import "LCShareProtocol.h"
#define LCQQAppKey @"1105441614"        //@"1104759652"

@interface LCQQShare : NSObject<LCShareProtocol>

@end
