//
//  LCMomentModule.h
//  LCWeb
//
//  Created by MengLingChao on 2018/7/8.
//  Copyright © 2018年 MengLingChao. All rights reserved.
//

#import <Foundation/Foundation.h>
//#import <LCMediator/LCMomentModuleProtocol.h>
#import "LCMomentModuleProtocol.h"

@interface LCMomentModule : NSObject<LCMomentModule>

@end
