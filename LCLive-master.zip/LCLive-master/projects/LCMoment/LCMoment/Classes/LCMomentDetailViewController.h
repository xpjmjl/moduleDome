//
//  LCMomentDetailViewController.h
//  Pods
//
//  Created by MengLingChao on 2018/7/20.
//

#import <UIKit/UIKit.h>

/**动态详情*/
@interface LCMomentDetailViewController : UIViewController

@property (nonatomic,copy)NSString *momentId;

@end
