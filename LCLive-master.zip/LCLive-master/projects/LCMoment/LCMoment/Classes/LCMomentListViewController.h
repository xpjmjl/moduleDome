//
//  LCMomentListViewController.h
//  LCMoment
//
//  Created by MengLingChao on 2018/7/20.
//

#import <UIKit/UIKit.h>

/**动态列表界面*/
@interface LCMomentListViewController : UIViewController

@end
