//
//  LCWebViewController.h
//  LCWeb
//
//  Created by MengLingChao on 2018/7/8.
//  Copyright © 2018年 MengLingChao. All rights reserved.
//

#import <UIKit/UIKit.h>

/**h5*/
@interface LCWebViewController : UIViewController

@property (nonatomic,copy)NSString *urlString;

@end
