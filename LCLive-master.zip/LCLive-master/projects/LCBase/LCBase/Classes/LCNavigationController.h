//
//  LCNavigationController.h
//  LCBase
//
//  Created by MengLingChao on 2018/7/8.
//

#import <UIKit/UIKit.h>

@interface LCNavigationController : UINavigationController

@end
