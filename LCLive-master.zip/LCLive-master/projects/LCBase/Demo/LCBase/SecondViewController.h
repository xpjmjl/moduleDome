//
//  TwoViewController.h
//  MengNavigation
//
//  Created by menglingchao on 2018/1/5.
//  Copyright © 2018年 Google Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LCBaseViewController.h"

@interface SecondViewController : LCBaseViewController

@end
