//
//  LCMeModule.h
//  LCMe
//
//  Created by MengLingChao on 2018/7/8.
//  Copyright © 2018年 MengLingChao. All rights reserved.
//

#import <Foundation/Foundation.h>
//#import <LCMediator/LCMeModuleProtocol.h>
#import "LCMeModuleProtocol.h"

@interface LCMeModule : NSObject<LCMeModule>

@end
